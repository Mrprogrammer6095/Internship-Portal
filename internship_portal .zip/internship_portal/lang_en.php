<?php
$lang = array(
    "login" => "Login",
    "email" => "Email",
    "password" => "Password",
    "role" => "Select Role",
    "remember_me" => "Remember Me",
    "forgot_password" => "Forgot your password?",
    "sign_up" => "Sign up here",
    "dont_have_account" => "Don't have an account?",
    "error_message" => "Invalid credentials, please try again.",
);
?>
