<?php
$user_id = $_SESSION['user_id']; // Get logged-in user's ID
$sql = "SELECT resume FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
if ($row['resume']) {
    echo "<a href='" . $row['resume'] . "'>Download Resume</a>";
} else {
    echo "No resume uploaded yet.";
}
?>
