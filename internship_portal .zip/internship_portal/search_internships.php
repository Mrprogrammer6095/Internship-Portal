<?php
include 'db_connection.php';

// Fetch search filters from GET
$location = $_GET['location'] ?? '';
$salary = $_GET['salary'] ?? '';

// Create query based on filters
$query = "SELECT * FROM internships WHERE 1";
if ($location) $query .= " AND location LIKE '%$location%'";
if ($salary) $query .= " AND salary >= $salary";

$result = $conn->query($query);

while ($row = $result->fetch_assoc()) {
    echo "<div>";
    echo "<h3>" . $row['title'] . "</h3>";
    echo "<p>Location: " . $row['location'] . "</p>";
    echo "<p>Salary: " . $row['salary'] . "</p>";
    echo "</div>";
}
?>

<form action="search_internships.php" method="GET">
    <input type="text" name="location" placeholder="Location">
    <input type="number" name="salary" placeholder="Minimum Salary">
    <button type="submit">Search</button>
</form>
