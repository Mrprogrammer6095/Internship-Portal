def chat_response(message):
    # Simple bot logic; replace with OpenAI/GPT model later
    if "internship" in message.lower():
        return "You can find internships under the 'Internships' section!"
    elif "skills" in message.lower():
        return "Upload your resume to detect skills and missing ones."
    else:
        return "I'm here to help! Ask anything related to internships or careers."
