# ai/recommendation_model.py
def recommend_internships(user_skills):
    # Dummy data
    internships = [
        {"title": "Web Development Intern", "skills": ["HTML", "CSS", "JavaScript"]},
        {"title": "Data Science Intern", "skills": ["Python", "Pandas", "Machine Learning"]},
        {"title": "Cybersecurity Intern", "skills": ["Networking", "Python", "Security"]}
    ]

    recommended = []
    for i in internships:
        if any(skill in user_skills for skill in i["skills"]):
            recommended.append(i)
    
    return recommended
