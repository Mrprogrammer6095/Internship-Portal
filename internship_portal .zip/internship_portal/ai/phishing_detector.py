# ai/phishing_detector.py
import re

def detect_url(url):
    suspicious_keywords = ['login', 'verify', 'update', 'secure', 'account', 'webscr', 'ebayisapi', 'banking']
    is_suspicious = any(keyword in url.lower() for keyword in suspicious_keywords)

    pattern = r"(http[s]?://)?([^\s]+\.[^\s]+)"
    if not re.match(pattern, url):
        return "Invalid URL format"

    if is_suspicious or len(url) > 75:
        return "Phishing suspected"
    else:
        return "URL looks safe"
