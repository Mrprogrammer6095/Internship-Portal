<?php
$lang = array(
    "login" => "लॉगिन",
    "email" => "ईमेल",
    "password" => "पासवर्ड",
    "role" => "भूमिका चुनें",
    "remember_me" => "मुझे याद रखें",
    "forgot_password" => "पासवर्ड भूल गए?",
    "sign_up" => "यहाँ साइन अप करें",
    "dont_have_account" => "क्या आपके पास खाता नहीं है?",
    "error_message" => "अमान्य प्रमाण पत्र, कृपया फिर से प्रयास करें।",
);
?>
