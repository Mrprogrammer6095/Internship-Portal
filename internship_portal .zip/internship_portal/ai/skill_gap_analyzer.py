# ai/skill_gap_analyzer.py
def analyze_skill_gap(user_skills, target_skills):
    missing_skills = [skill for skill in target_skills if skill not in user_skills]
    return missing_skills
