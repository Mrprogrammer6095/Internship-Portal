<?php
session_start();
if (!isset($_SESSION['employer_id'])) {
    header("Location: employer_login.php");
    exit();
}
include 'db.php';

$employer_id = $_SESSION['employer_id'];
$query = $conn->prepare("SELECT email FROM employers WHERE id = ?");
$query->bind_param("i", $employer_id);
$query->execute();
$result = $query->get_result();
$employer = $result->fetch_assoc();
$query->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Employer Dashboard</title>
  <link rel="stylesheet" href="css/employer_dashboard.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
  <div class="dashboard-container">
    <!-- Navbar -->
    <nav class="navbar">
      <div class="navbar-left">
        <h2>Welcome, <?php echo htmlspecialchars($employer['email']); ?></h2>
      </div>
      <div class="navbar-right">
        <a href="post_internship.php">Post Internship</a>
        <a href="view_applications.php">Applications</a>
        <a href="view_resume.php">Resumes</a>
        <a href="messages.php">Messages</a>
        <a href="settings.php">Settings</a>
        <a href="logout.php">Logout</a>
        <button id="dark-mode-toggle" title="Toggle Dark Mode">🌙</button>
      </div>
    </nav>

    <!-- Dashboard Content -->
    <main class="dashboard-content">
      <h3>Employer Dashboard</h3>
      <p>Manage your internships, review applications, and communicate with candidates.</p>

      <div class="dashboard-grid">
        <a href="post_internship.php" class="dashboard-card">
          <i class="fas fa-upload"></i>
          <span>Post Internship</span>
        </a>
        <a href="view_applications.php" class="dashboard-card">
          <i class="fas fa-folder-open"></i>
          <span>View Applications</span>
        </a>
        <a href="view_resume.php" class="dashboard-card">
          <i class="fas fa-file-alt"></i>
          <span>View Resumes</span>
        </a>
        <a href="messages.php" class="dashboard-card">
          <i class="fas fa-comments"></i>
          <span>Messages</span>
        </a>
        <a href="settings.php" class="dashboard-card">
          <i class="fas fa-cogs"></i>
          <span>Settings</span>
        </a>
      </div>
    </main>
  </div>

  <script>
    const toggleButton = document.getElementById('dark-mode-toggle');
    toggleButton.addEventListener('click', () => {
      document.body.classList.toggle('dark-mode');
      localStorage.setItem('employerDarkMode', document.body.classList.contains('dark-mode'));
    });

    if (localStorage.getItem('employerDarkMode') === 'true') {
      document.body.classList.add('dark-mode');
    }
  </script>
</body>
</html>
