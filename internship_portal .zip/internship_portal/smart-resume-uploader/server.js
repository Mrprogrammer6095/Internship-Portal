const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const aiLogic = require('./aiLogic');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.static('public'));

const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: (req, file, cb) => cb(null, file.originalname),
});
const upload = multer({ storage });

app.post('/upload', upload.single('resume'), async (req, res) => {
  const filePath = path.join(__dirname, 'uploads', req.file.filename);
  const aiResult = await aiLogic.analyzeResume(filePath);

  res.json({
    success: true,
    message: 'Resume uploaded and analyzed successfully!',
    aiResult,
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

// Chat-style guidance
app.post('/chat-guidance', (req, res) => {
    const message = req.body.message;
    const reply = `🤖 Based on your interest in "${message}", I recommend checking internships in AI, Web Dev, or Cybersecurity. Want me to show top listings?`; // Replace with AI logic if needed
    res.json({ reply });
});

// Phishing Detection
app.post('/phishing-check', (req, res) => {
    const url = req.body.url;
    const isPhishing = url.includes("free") || url.includes("login-verify"); // Example check (add ML logic later)
    res.json({ result: isPhishing ? "🚨 This might be a phishing link!" : "✅ Safe URL" });
});
