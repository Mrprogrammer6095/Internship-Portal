<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['employer_id'])) {
    header("Location: login.php");
    exit();
}

$employer_id = $_SESSION['employer_id'];

$sql = "SELECT applications.id, users.full_name, users.email, internships.title, applications.status 
        FROM applications
        INNER JOIN users ON applications.user_id = users.id
        INNER JOIN internships ON applications.internship_id = internships.id
        WHERE internships.employer_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $employer_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Interns</title>
    <link rel="stylesheet" href="css/theme.css">
</head>
<body>

    <div class="theme-toggle">
        <span>🌞</span>
        <input type="checkbox" id="theme-switch">
        <span>🌙</span>
    </div>

    <div class="dashboard-container">
        <h2>Track Interns</h2>
        <table>
            <thead>
                <tr>
                    <th>Intern Name</th>
                    <th>Email</th>
                    <th>Internship</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script>
        // Theme Toggle Script
        const themeSwitch = document.getElementById("theme-switch");

        if (localStorage.getItem("theme") === "dark") {
            document.body.classList.add("dark-mode");
            themeSwitch.checked = true;
        }

        themeSwitch.addEventListener("change", () => {
            document.body.classList.toggle("dark-mode");
            localStorage.setItem("theme", document.body.classList.contains("dark-mode") ? "dark" : "light");
        });
    </script>

</body>
</html>
