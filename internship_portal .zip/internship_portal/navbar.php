<nav class="navbar">
    <div class="logo">
        <a href="index.php">Internship Portal</a>
    </div>
    <div class="nav-links">
        <a href="index.php" class="active">Home</a>
        <a href="internships.php">Internships</a>
        <a href="profile.php">Profile</a>
        <a href="login.php">Login</a>
        <a href="register.php">Sign Up</a>
    </div>
</nav>
