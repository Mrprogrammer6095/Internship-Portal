<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Internship Listings</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Full-Page Background */
        body {
            background: url('images/listings.jpg') no-repeat center center/cover;
            background-size: cover;
            background-attachment: fixed;
            font-family: 'Poppins', sans-serif;
            color: white;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .internship-container {
            max-width: 1200px;
            margin: auto;
            padding: 30px;
            text-align: center;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        .internship-header {
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.6);
        }

        .internship-card {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 20px;
            margin: 15px auto;
            max-width: 800px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            text-align: center;
        }

        .internship-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.5);
        }

        .apply-btn {
            background: #ff7eb3;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
            font-size: 16px;
        }

        .apply-btn:hover {
            background: #ff4a90;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .internship-container {
                width: 90%;
                padding: 20px;
            }

            .internship-header {
                font-size: 24px;
            }

            .apply-btn {
                font-size: 14px;
                padding: 10px 15px;
            }
        }
    </style>
</head>
<body>
    <div class="internship-container">
        <div class="internship-header">
            Browse Latest Internship Opportunities
        </div>
        
        <div class="internship-card">
            <h3> Accounting Intern</h3>
            <p>Company: Jyoti Waghmode and Associates | Duration: 3 Months | Stipend: ₹20,000</p>
            <button class="apply-btn">Apply Now</button>
        </div>

        <div class="internship-card">
            <h3>CAD Design Intern</h3>
            <p>Company: Sanprotek Sanitary Process | Duration: 6 Months | Stipend: ₹15,000</p>
            <button class="apply-btn">Apply Now</button>
        </div>
    </div>
</body>
</html>
