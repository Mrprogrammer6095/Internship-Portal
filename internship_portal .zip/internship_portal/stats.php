<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Internship Stats</title>
    <link rel="stylesheet" href="css/stats.css">
</head>
<body>
    <div class="container">
        <h1 class="page-title">Internship Statistics</h1>
        <!-- Add your stats here -->
    </div>
</body>
</html>
