<?php
session_start();
include 'db/db_connection.php'; // Update path if needed

// Only admin access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$result = $conn->query("SELECT user_id, skills, recommendations, missing_skills, uploaded_at FROM resume_data ORDER BY uploaded_at DESC");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resume Insights</title>
    <link rel="stylesheet" href="css/admin.css"> <!-- Your admin styles -->
    <style>
        .resume-table {
            width: 90%;
            margin: 30px auto;
            border-collapse: collapse;
        }
        .resume-table th, .resume-table td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }
        .resume-table th {
            background-color: #007bff;
            color: #fff;
        }
    </style>
</head>
<body>
    <h2 style="text-align:center;">Resume Insights</h2>
    <table class="resume-table">
        <tr>
            <th>User ID</th>
            <th>Extracted Skills</th>
            <th>Recommended Roles</th>
            <th>Missing Skills</th>
            <th>Uploaded At</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['user_id']; ?></td>
            <td><?= htmlspecialchars($row['skills']); ?></td>
            <td><?= htmlspecialchars($row['recommendations']); ?></td>
            <td><?= htmlspecialchars($row['missing_skills']); ?></td>
            <td><?= $row['uploaded_at']; ?></td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
