<?php
session_start();
require 'db_connect.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $role = $_POST['role']; // Role selection (Admin, Employer, User)

    if (empty($email) || empty($password)) {
        die("❌ Error: Email and Password cannot be empty.");
    }

    // Table selection based on role
    switch ($role) {
        case "admin":
            $query = "SELECT id, email FROM admin WHERE email = ? AND password = ?";
            break;
        case "employer":
            $query = "SELECT id, email FROM employers WHERE email = ? AND password = ?";
            break;
        case "user":
            $query = "SELECT id, email FROM users WHERE email = ? AND password = ?";
            break;
        default:
            die("❌ Error: Invalid role selected.");
    }

    // Prepare and execute the query
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $email);
            $stmt->fetch();

            // Store session variables based on role
            if ($role == "admin") {
                $_SESSION['admin_id'] = $id;
                header("Location: admin_dashboard.php");
                exit();
            } elseif ($role == "employer") {
                $_SESSION['employer_id'] = $id;
                header("Location: employer_dashboard.php");
                exit();
            } elseif ($role == "user") {
                $_SESSION['user_id'] = $id;
                header("Location: user_dashboard.php");
                exit();
            }
        } else {
            echo "<script>alert('❌ Incorrect Email or Password!'); window.location.href='login.php';</script>";
        }

        $stmt->close();
    } else {
        die("❌ Query Preparation Failed: " . $conn->error);
    }

    $conn->close();
} else {
    echo "<script>alert('❌ Invalid Request!'); window.location.href='login.php';</script>";
}
?>
