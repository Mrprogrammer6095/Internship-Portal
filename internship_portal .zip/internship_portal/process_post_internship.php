

<?php

echo "<pre>";
print_r($_POST);
echo "</pre>";

include 'db_connect.php'; // Ensure database connection is included

// Start session
session_start();

// Check if employer is logged in
if (!isset($_SESSION['employer_id'])) {
    die("❌ Employer not logged in!");
}

// Get form data
$title = $_POST['title'];
$company_name = $_POST['company_name'];
$description = $_POST['description'];
$location = $_POST['location'];
$salary = isset($_POST['salary']) ? $_POST['salary'] : "Not specified"; // Default value
$employer_id = $_SESSION['employer_id']; // Getting employer ID from session

// Prepare SQL statement
$sql = "INSERT INTO internships (title, company_name, description, location, salary, employer_id) 
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

// **Debugging: Check if SQL prepared successfully**
if (!$stmt) {
    die("❌ SQL Error: " . $conn->error);
}

// Bind parameters
$stmt->bind_param("sssssi", $title, $company_name, $description, $location, $salary, $employer_id);

// Execute the statement
if ($stmt->execute()) {
    echo "✅ Internship posted successfully!";
} else {
    echo "❌ Error posting internship: " . $stmt->error;
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
