from flask import Flask, request, jsonify
from flask_cors import CORS
import os

# === Import your AI modules ===
from ai.resume_parser import extract_from_resume
from ai.recommendation_model import recommend_internships
from ai.skill_gap_analyzer import analyze_skill_gap
from ai.chat_style_ai import chat_response
from ai.phishing_detector import detect_url

# === Setup Flask app ===
app = Flask(__name__)
CORS(app)  # Allow Cross-Origin requests

# === Folder for uploaded resumes ===
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# === Test Route to Check if Server is Running ===
@app.route('/', methods=['GET'])
def index():
    return jsonify({"message": "Internship Portal AI Backend is running!"})


# === Resume Upload: Extract Skills, Recommend Internships, Analyze Skill Gap ===
@app.route('/upload-resume', methods=['POST'])
def upload_resume():
    if 'resume' not in request.files:
        return jsonify({"error": "No resume file uploaded"}), 400

    file = request.files['resume']
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)

    try:
        # Step 1: Extract skills
        skills = extract_from_resume(file_path)

        # Step 2: Recommend internships based on skills
        recommendations = recommend_internships(skills)

        # Step 3: Analyze skill gap
        target_skills = ["flask", "machine learning", "html", "sql"]
        missing_skills = analyze_skill_gap(skills, target_skills)

        return jsonify({
            "extracted_skills": skills,
            "recommended_internships": recommendations,
            "missing_skills": missing_skills
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# === AI Chat Assistant ===
@app.route('/ask', methods=['POST'])
def ask():
    data = request.get_json()
    user_input = data.get("user_input")

    if not user_input:
        return jsonify({"error": "No user input provided"}), 400

    try:
        response = chat_response(user_input)
        return jsonify({"response": response})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# === Phishing URL Detection ===
@app.route('/check-url', methods=['POST'])
def check_url():
    data = request.get_json()
    url = data.get('url')

    if not url:
        return jsonify({"error": "No URL provided"}), 400

    try:
        result = detect_url(url)
        return jsonify({"result": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# === Run Flask App ===
if __name__ == '__main__':
    app.run(port=5001, debug=True)
