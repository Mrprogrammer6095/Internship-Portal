import fitz  # PyMuPDF
import spacy
import json
import sys

# Load NLP model
nlp = spacy.load("en_core_web_sm")

# Get filename from command-line args
resume_file = sys.argv[1]

# Read PDF
doc = fitz.open(resume_file)
text = ""
for page in doc:
    text += page.get_text()

# NLP processing
doc_nlp = nlp(text)
skills = []

# Sample skill keywords (expand this list)
skill_keywords = ["python", "sql", "excel", "java", "html", "css", "javascript",
                  "react", "ml", "ai", "linux", "networking", "flask", "c++"]

for token in doc_nlp:
    word = token.text.lower()
    if word in skill_keywords and word not in skills:
        skills.append(word)

# Return skills as JSON
print(json.dumps({"skills": skills}))
