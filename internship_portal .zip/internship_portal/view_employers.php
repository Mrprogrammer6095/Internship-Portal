<?php
include('db_connection.php');
$query = "SELECT * FROM employers";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Employers</title>
    <link rel="stylesheet" href="css/view_employers.css">
</head>
<body>
    <div class="container">
        <h1 class="page-title">Employers List</h1>
        <table class="employer-table">
            <thead>
                <tr>
                    <th>Employer ID</th>
                    <th>Company Name</th>
                    <th>Contact Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($employer = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $employer['id']; ?></td>
                        <td><?php echo $employer['company_name']; ?></td>
                        <td><?php echo $employer['contact_email']; ?></td>
                        <td>
                            <button class="btn approve">Approve</button>
                            <button class="btn deny">Deny</button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
