<?php
	$conn = new mysqli('localhost', 'root', '', 'db_issm') or die(mysqli_error());
?>