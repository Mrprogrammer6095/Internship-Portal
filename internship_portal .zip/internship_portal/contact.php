<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    // You can store it in the database or send email
    echo "<script>alert('Message received! Thank you.');</script>";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us</title>
    <link rel="stylesheet" href="css/contact.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <section class="contact-section">
        <h2>Contact Us</h2>
        <p>If you have any queries, feel free to reach out to us using the form below.</p>

        <form class="contact-form" action="contact.php" method="POST">
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" placeholder="Your Name" required>

            <label for="email">Email:</label>
            <input type="email" name="email" id="email" placeholder="you@example.com" required>

            <label for="message">Message:</label>
            <textarea name="message" id="message" placeholder="Your Message" rows="5" required></textarea>

            <button type="submit">Send Message</button>
        </form>

        <div class="map-container">
            <!-- Google Maps iframe with Solapur location -->
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.377320109197!2d75.8986199!3d17.659918499999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc5dcfefea3b5b7%3A0x95d5cda62aa8edc5!2sSolapur%2C%20Maharashtra%2C%20India!5e0!3m2!1sen!2sin!4v1712012345678!5m2!1sen!2sin"
                width="100%" height="300" frameborder="0"
                allowfullscreen=""
                aria-hidden="false"
                tabindex="0">
            </iframe>
        </div>
    </section>

    <script>
        // Optional: Dark mode support if toggled globally
        if (localStorage.getItem("darkMode") === "true") {
            document.body.classList.add("dark-mode");
        }
    </script>
</body>
</html>
