<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT applications.id, internships.title, internships.company_name, applications.resume_link, applications.status 
        FROM applications 
        JOIN internships ON applications.internship_id = internships.id 
        WHERE applications.user_id = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Database error: " . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Applications</title>
    <link rel="stylesheet" href="css/view_applications.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .applications-container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 30px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .applications-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }

        .applications-table th,
        .applications-table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        .applications-table th {
            background-color: #007bff;
            color: white;
        }

        .applications-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .view-resume-btn {
            background-color: #28a745;
            color: white;
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }

        .view-resume-btn:hover {
            background-color: #218838;
        }

        .status-pending {
            color: orange;
            font-weight: bold;
        }

        .status-approved {
            color: green;
            font-weight: bold;
        }

        .status-rejected {
            color: red;
            font-weight: bold;
        }

        .back-btn {
            display: inline-block;
            margin-top: 25px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .back-btn:hover {
            background-color: #0056b3;
        }

        p {
            text-align: center;
            font-size: 18px;
            margin-top: 20px;
            color: #555;
        }
    </style>
</head>
<body>

<div class="applications-container">
    <h1>📄 Your Internship Applications</h1>
    
    <?php if ($result && $result->num_rows > 0) { ?>
        <table class="applications-table">
            <thead>
                <tr>
                    <th>Internship Title</th>
                    <th>Company</th>
                    <th>Resume</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['company_name']); ?></td>
                        <td>
                            <?php if (!empty($row['resume_link'])) { ?>
                                <a href="<?php echo htmlspecialchars($row['resume_link']); ?>" target="_blank" class="view-resume-btn">View</a>
                            <?php } else { ?>
                                <span style="color: gray;">No Resume</span>
                            <?php } ?>
                        </td>
                        <td>
                            <?php 
                                if ($row['status'] == 'Pending') {
                                    echo '<span class="status-pending">Pending</span>';
                                } elseif ($row['status'] == 'Approved') {
                                    echo '<span class="status-approved">Approved</span>';
                                } else {
                                    echo '<span class="status-rejected">Rejected</span>';
                                }
                            ?>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    <?php } else { ?>
        <p>No applications found.</p>
    <?php } ?>

    <a href="user_dashboard.php" class="back-btn">← Back to Dashboard</a>
</div>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
