<?php
include 'config.php';
session_start();

// Ensure employer is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employer') {
    header("Location: login.php");
    exit();
}

$employer_id = $_SESSION['user_id'];

// Check if internship ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("❌ Error: Internship ID is required.");
}

$internship_id = $_GET['id'];

// Fetch internship to confirm ownership
$sql = "SELECT * FROM internships WHERE id = ? AND employer_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $internship_id, $employer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("❌ Error: Unauthorized access or internship not found.");
}

// If user confirms deletion
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $delete_sql = "DELETE FROM internships WHERE id = ? AND employer_id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->bind_param("ii", $internship_id, $employer_id);

    if ($delete_stmt->execute()) {
        echo "<script>alert('✅ Internship deleted successfully!'); window.location.href='employer_dashboard.php';</script>";
        exit();
    } else {
        echo "❌ Error deleting internship: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Internship</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }
        .delete-container {
            width: 50%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }
        .btn {
            padding: 10px 15px;
            color: white;
            background: red;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background: darkred;
        }
        .btn-cancel {
            background: gray;
        }
        .btn-cancel:hover {
            background: black;
        }
    </style>
</head>
<body>

<div class="delete-container">
    <h2>⚠️ Confirm Internship Deletion</h2>
    <p>Are you sure you want to delete this internship?</p>
    <form action="" method="POST">
        <button type="submit" class="btn">❌ Yes, Delete</button>
        <a href="employer_dashboard.php" class="btn btn-cancel">🔙 Cancel</a>
    </form>
</div>

</body>
</html>
