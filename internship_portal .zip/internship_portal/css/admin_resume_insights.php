<?php
session_start();
include '../db.php'; // Adjust path if needed

// Optional: check if admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$query = $conn->query("SELECT * FROM resume_insights ORDER BY uploaded_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resume Insights | Admin Panel</title>
    <link rel="stylesheet" href="../css/admin_resume_insights.css">
</head>
<body>
    <div class="container">
        <h2>📄 Resume Insights</h2>
        <table>
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Extracted Skills</th>
                    <th>Recommended Roles</th>
                    <th>Missing Skills</th>
                    <th>Uploaded At</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $query->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['user_id']) ?></td>
                    <td><?= htmlspecialchars($row['extracted_skills']) ?></td>
                    <td><?= htmlspecialchars($row['recommended_internships']) ?></td>
                    <td><?= htmlspecialchars($row['missing_skills']) ?></td>
                    <td><?= htmlspecialchars($row['uploaded_at']) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
