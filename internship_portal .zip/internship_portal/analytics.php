<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics</title>
    <link rel="stylesheet" href="css/analytics.css">
</head>
<body>
    <div class="container">
        <h1 class="page-title">Analytics Dashboard</h1>
        <!-- Add your charts/graphs here -->
    </div>
</body>
</html>
