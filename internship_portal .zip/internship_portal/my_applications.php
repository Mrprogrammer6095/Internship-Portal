<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';
$user_id = $_SESSION['user_id'];

// Join internships and applications tables
$stmt = $conn->prepare("
    SELECT i.title, i.company_name, i.location, i.salary, i.description, a.applied_at 
    FROM applications a 
    INNER JOIN internships i ON a.internship_id = i.id 
    WHERE a.user_id = ? 
    ORDER BY a.applied_at DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$applications = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Applications</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #7f00ff, #e100ff);
            margin: 0;
            padding: 30px;
            color: #fff;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 32px;
        }

        .applications-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            max-width: 1200px;
            margin: auto;
        }

        .card {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 20px;
            backdrop-filter: blur(6px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card h3 {
            margin: 0;
            color: #ffffff;
        }

        .card p {
            margin: 8px 0;
            font-size: 14px;
            color: #f0f0f0;
        }

        .applied-date {
            font-size: 13px;
            color: #d0d0d0;
            margin-top: 10px;
        }

        .btn-back {
            display: block;
            width: max-content;
            margin: 20px auto 0;
            padding: 10px 20px;
            background: #ffffff;
            color: #7f00ff;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
        }

        .btn-back:hover {
            background: #ddd;
            color: #4c00b0;
        }
    </style>
</head>
<body>

<h2>📂 My Applications</h2>

<div class="applications-grid">
    <?php if (count($applications) > 0): ?>
        <?php foreach ($applications as $app): ?>
            <div class="card">
                <h3><?php echo htmlspecialchars($app['title']); ?></h3>
                <p><strong>Company:</strong> <?php echo htmlspecialchars($app['company_name']); ?></p>
                <p><strong>Location:</strong> <?php echo htmlspecialchars($app['location']); ?></p>
                <p><strong>Stipend:</strong> ₹<?php echo htmlspecialchars($app['salary']); ?> / month</p>
                <p class="applied-date"><strong>Applied on:</strong> <?php echo date("d M Y", strtotime($app['applied_at'])); ?></p>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="text-align: center;">You haven't applied to any internships yet.</p>
    <?php endif; ?>
</div>

<a href="user_dashboard.php" class="btn-back">← Back to Dashboard</a>

</body>
</html>
