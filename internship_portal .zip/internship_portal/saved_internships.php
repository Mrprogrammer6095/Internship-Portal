<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Saved Internships</title>
    <link rel="stylesheet" href="css/saved_internships.css">
    <style>
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background: url('images/listings.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: flex-start;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            padding: 40px 20px;
            box-sizing: border-box;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #ffffff;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.7);
            font-size: 2.5rem;
        }

        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 25px;
        }

        .card {
            backdrop-filter: blur(20px);
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.25);
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            color: #fff;
            transition: transform 0.3s ease, background 0.3s ease;
        }

        .card:hover {
            transform: translateY(-6px);
            background: rgba(255, 255, 255, 0.25);
        }

        .card h3 {
            margin-top: 0;
            font-size: 1.3rem;
            color: #00ccff;
        }

        .card p {
            margin: 8px 0;
            font-size: 0.95rem;
        }

        .card button {
            background-color: rgba(0, 123, 255, 0.8);
            border: none;
            color: white;
            padding: 10px 16px;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 15px;
            backdrop-filter: blur(10px);
        }

        .card button:hover {
            background-color: rgba(0, 123, 255, 1);
        }

        @media (max-width: 600px) {
            h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>💾 Saved Internships</h1>
        <div class="grid-container">
            <div class="card">
                <h3>Accounting Intern</h3>
                <p>Company: Jyoti Waghmode & Associates (CA Firm)</p>
                <p>Location: Remote</p>
            </div>

            <div class="card">
                <h3>CAD Design Intern</h3>
                <p>Company: Toolcon Systems</p>
                <p>Location: Pune</p>
            </div>

            <div class="card">
                <h3>Quality Inspection Intern</h3>
                <p>Company: Sanprotek Sanitar Porcess</p>
                <p>Location: MIDC, Bhosari</p>
            </div>

            <div class="card">
                <h3>Production Planning Intern</h3>
                <p>Company: Rasco Industries</p>
                <p>Location: Chakan</p>
            </div>
        </div>
    </div>
</body>
</html>
