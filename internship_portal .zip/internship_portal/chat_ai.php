<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $msg = $_POST["message"];
    $cmd = escapeshellcmd("python app.py " . escapeshellarg($msg));
    $response = shell_exec($cmd);
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>AI Chat Assistant</title>
</head>
<body>
  <h2>Chat with AI Assistant</h2>
  <form method="post">
    <input type="text" name="message" placeholder="Ask something..." required>
    <button type="submit">Send</button>
  </form>

  <?php if (!empty($response)) : ?>
    <div>
      <strong>AI:</strong>
      <p><?php echo htmlspecialchars($response); ?></p>
    </div>
  <?php endif; ?>
</body>
</html>
