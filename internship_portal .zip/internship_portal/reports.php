<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Insights</title>
    <link rel="stylesheet" href="css/reports.css">
</head>
<body>

    <header>
        <h2>View Insights</h2>
        <a href="admin_dashboard.php" class="back-btn">Back</a>
    </header>

    <div class="dashboard-container">
        <div class="card">
            <h3>User Analytics</h3>
            <p>See platform engagement and user trends.</p>
            <a href="analytics.php">View Analytics</a>
        </div>

        <div class="card">
            <h3>Internship Stats</h3>
            <p>Track internship applications and success rate.</p>
            <a href="internship_stats.php">View Stats</a>
        </div>
    </div>

</body>
</html>
