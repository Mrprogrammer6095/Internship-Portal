<?php
session_start();
if (!isset($_SESSION["employer_id"])) {
    header("Location: employer_login.php");
    exit();
}

require 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $description = $_POST["description"];
    $location = $_POST["location"];
    $salary = $_POST["salary"];
    $employer_id = $_SESSION["employer_id"]; // Get employer ID from session

    $sql = "INSERT INTO internships (title, description, location, salary, employer_id) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("ssssi", $title, $description, $location, $salary, $employer_id);
        if ($stmt->execute()) {
            echo "<script>alert('✅ Internship posted successfully!');</script>";
        } else {
            echo "<script>alert('❌ Error posting internship.');</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('❌ Database error.');</script>";
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Internship</title>
    <link rel="stylesheet" href="css/post_internship.css">
</head>
<body>
<body style="background: url('images/post_int.jpg') no-repeat center center fixed; background-size: cover;"></body>
<header>
    <nav>
        <ul>
            <li><a href="employer_dashboard.php">Dashboard</a></li>
            <li><a href="manage_internships.php">Manage Internships</a></li>
            <li><a href="view_applications.php">View Applications</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
</header>

<div class="container">
    <h2>Post Internship</h2>
    <form action="post_internship.php" method="post">
        <label for="title">Internship Title:</label>
        <input type="text" id="title" name="title" required>

        <label for="description">Internship Description:</label>
        <textarea id="description" name="description" required></textarea>

        <label for="location">Location:</label>
        <input type="text" id="location" name="location" required>

        <label for="salary">Stipend:</label>
        <input type="text" id="salary" name="salary" required>

        <button type="submit">Post Internship</button>
    </form>
</div>

</body>
</html>
