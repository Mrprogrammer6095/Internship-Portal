<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['resume']) && $_FILES['resume']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['resume'];
        $fileName = $file['name'];
        $fileTmp = $file['tmp_name'];
        $fileType = mime_content_type($fileTmp);

        if ($fileType !== 'application/pdf') {
            header("Location: resume_parser.php?error=Only PDF files are allowed.");
            exit();
        }

        $destination = "uploads/" . time() . "_" . basename($fileName);
        if (move_uploaded_file($fileTmp, $destination)) {
            // ✅ Here call your Python API (Flask) to extract data
            header("Location: resume_parser.php?success=Resume uploaded successfully. Analyzing...");
            // You can redirect to a result display page
        } else {
            header("Location: resume_parser.php?error=Failed to upload the resume.");
        }
    } else {
        header("Location: resume_parser.php?error=No file uploaded or unknown error.");
    }
    exit();
}
?>
