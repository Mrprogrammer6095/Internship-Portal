<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Internship Portal</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- Header -->
<header>
    <div class="logo">Internship Portal</div>
    <nav>
        <ul>
            <li><a href="index.php" class="nav-btn">Home</a></li>
            <li><a href="about.php" class="nav-btn">About Us</a></li>
            <li><a href="contact.php" class="nav-btn">Contact</a></li>
            <li><a href="login.php" class="nav-btn">Login</a></li>
        </ul>
    </nav>
</header>

<!-- About Us Section -->
<section class="about">
    <h1>About Us</h1>
    <p>Welcome to the Internship Portal, your one-stop platform for finding the best internship opportunities!</p>

    <div class="about-cards">
        <div class="about-card">
            <img src="icons/mission.png" alt="Mission">
            <h2>Our Mission</h2>
            <p>Connecting students with high-quality internships from trusted employers.</p>
        </div>

        <div class="about-card">
            <img src="icons/vision.png" alt="Vision">
            <h2>Our Vision</h2>
            <p>To be the leading platform for career-building internships worldwide.</p>
        </div>

        <div class="about-card">
            <img src="icons/team.png" alt="Team">
            <h2>Our Team</h2>
            <p>We are a team of professionals dedicated to bridging the gap between students and the industry.</p>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="footer">
    &copy; 2025 Internship Portal | All rights reserved.
</footer>

</body>
</html>
