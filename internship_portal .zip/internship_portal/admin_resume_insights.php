<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
include 'db.php';

// Fetch resume insights
$query = "SELECT r.id, u.full_name, r.extracted_skills, r.recommended_internships, r.missing_skills, r.uploaded_at 
          FROM resume_insights r
          JOIN users u ON r.user_id = u.id 
          ORDER BY r.uploaded_at DESC";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Resume Insights</title>
  <link rel="stylesheet" href="css/admin_resume_insights.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>
  <div class="container">
    <h2>Resume Insights</h2>
    <p>This panel shows resume-based skill extraction, recommendations, and gap analysis for all users.</p>

    <?php if ($result->num_rows > 0): ?>
      <div class="insights-grid">
        <?php while ($row = $result->fetch_assoc()): ?>
          <div class="insight-card">
            <h3><?php echo htmlspecialchars($row['full_name']); ?></h3>
            <p><strong>Uploaded:</strong> <?php echo date('d M Y', strtotime($row['uploaded_at'])); ?></p>
            <p><strong>Skills:</strong> <?php echo htmlspecialchars($row['extracted_skills']); ?></p>
            <p><strong>Recommended Internships:</strong><br> <?php echo nl2br(htmlspecialchars($row['recommended_internships'])); ?></p>
            <p><strong>Missing Skills:</strong><br> <?php echo nl2br(htmlspecialchars($row['missing_skills'])); ?></p>
          </div>
        <?php endwhile; ?>
      </div>
    <?php else: ?>
      <p>No resume insights found.</p>
    <?php endif; ?>

    <a href="admin_dashboard.php" class="back-btn">← Back to Dashboard</a>
  </div>
</body>
</html>
