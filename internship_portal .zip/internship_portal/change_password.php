<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password | Internship Portal</title>
    <link rel="stylesheet" href="css/style.css">  <!-- General Styles -->
    <link rel="stylesheet" href="css/change_password.css">  <!-- Page-Specific Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
<body style="background: url('images/change_pass.jpg') no-repeat center center fixed; background-size: cover;"></body>
<header>
    <div class="logo">Internship Portal</div>
    <nav>
        <ul>
            <li><a href="dashboard.php" class="nav-btn">Dashboard</a></li>
            <li><a href="internships.php" class="nav-btn">Internships</a></li>
            <li><a href="applications.php" class="nav-btn">Applications</a></li>
            <li><a href="profile.php" class="nav-btn">Profile</a></li>
            <li><a href="logout.php" class="nav-btn">Logout</a></li>
        </ul>
    </nav>
</header>

<!-- Change Password Form -->
<div class="change-password-container">
    <div class="change-password-card">
        <h2>Change Password</h2>
        <form action="process_change_password.php" method="POST">
            <div class="form-group">
                <label for="current_password"><i class="fas fa-lock"></i> Current Password</label>
                <input type="password" id="current_password" name="current_password" required>
            </div>
            <div class="form-group">
                <label for="new_password"><i class="fas fa-key"></i> New Password</label>
                <input type="password" id="new_password" name="new_password" required>
            </div>
            <div class="form-group">
                <label for="confirm_password"><i class="fas fa-check"></i> Confirm Password</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>
            <button type="submit" class="submit-btn"><i class="fas fa-save"></i> Save Changes</button>
        </form>
    </div>
</div>

</body>
</html>
