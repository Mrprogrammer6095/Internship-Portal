<?php
include 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    die("❌ Error: User not logged in.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['internship_id'])) {
    $internship_id = $_POST['internship_id'];
    $title = $_POST['title'];
    $company = $_POST['company'];
    $location = $_POST['location'];
    $description = $_POST['description'];
    $salary = $_POST['salary'];

    $sql = "UPDATE internships SET title=?, company=?, location=?, description=?, salary=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssdi", $title, $company, $location, $description, $salary, $internship_id);

    if ($stmt->execute()) {
        echo "✅ Internship updated successfully!";
    } else {
        echo "❌ Error updating internship: " . $conn->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Internship</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Edit Internship</h2>
    <form method="POST">
        <input type="hidden" name="internship_id" value="<?php echo $_GET['id']; ?>">
        <input type="text" name="title" placeholder="Internship Title" required><br>
        <input type="text" name="company" placeholder="Company Name" required><br>
        <input type="text" name="location" placeholder="Location" required><br>
        <textarea name="description" placeholder="Internship Description" required></textarea><br>
        <input type="number" name="salary" placeholder="Salary Amount"><br>
        <button type="submit">Update Internship</button>
    </form>
</body>
</html>
