<?php
session_start();
if (!isset($_SESSION["employer_id"])) {
    header("Location: employer_login.php");
    exit();
}

require 'db_connect.php';

// Fetch all internships posted by the logged-in employer
$employer_id = $_SESSION["employer_id"];
$sql = "SELECT id, title, description, location, salary FROM internships WHERE employer_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $employer_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Internships</title>
    <link rel="stylesheet" href="css/manage_internships.css">
</head>
<body>
<body style="background: url('images/man_int.jpg') no-repeat center center fixed; background-size: cover;"></body>
<header>
    <nav>
        <ul>
            <li><a href="employer_dashboard.php">Dashboard</a></li>
            <li><a href="post_internship.php">Post Internship</a></li>
            <li><a href="view_applications.php">View Applications</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
</header>

<div class="container">
    <h2>Manage Internships</h2>
    <div class="internship-list">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="internship-card">
                <h3><?php echo htmlspecialchars($row["title"]); ?></h3>
                <p><strong>Description:</strong> <?php echo htmlspecialchars($row["description"]); ?></p>
                <p><strong>Location:</strong> <?php echo htmlspecialchars($row["location"]); ?></p>
                <p><strong>Stipend:</strong> ₹<?php echo htmlspecialchars($row["salary"]); ?></p>
                <button class="delete-btn" onclick="deleteInternship(<?php echo $row['id']; ?>)">Delete</button>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<script>
function deleteInternship(id) {
    if (confirm("Are you sure you want to delete this internship?")) {
        window.location.href = "delete_internship.php?id=" + id;
    }
}
</script>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
