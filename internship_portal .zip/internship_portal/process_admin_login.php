<?php
session_start();
require 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT id, email, password FROM admin WHERE email = ?";
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $admin = $result->fetch_assoc();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_email'] = $admin['email'];
            header("Location: admin_dashboard.php"); // Redirect after successful login
            exit();
        } else {
            echo "<script>alert('❌ Invalid credentials'); window.location.href='admin_login.php';</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('❌ Database error.'); window.location.href='admin_login.php';</script>";
    }
}
$conn->close();
?>
