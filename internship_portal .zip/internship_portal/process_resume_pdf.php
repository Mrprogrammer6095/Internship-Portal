<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if a file was uploaded
if (isset($_FILES['resume']) && $_FILES['resume']['error'] == 0) {
    $file_tmp_path = $_FILES['resume']['tmp_name'];
    $file_name = $_FILES['resume']['name'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    // Allow only PDF files
    if ($file_ext !== 'pdf') {
        die("Only PDF files are allowed.");
    }

    // Send file to Flask API
    $api_url = "http://localhost:5001/upload-resume";
    $cfile = new CURLFile($file_tmp_path, 'application/pdf', $file_name);

    $post_fields = ['resume' => $cfile];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_status == 200) {
        $data = json_decode($response, true);
    } else {
        die("Error connecting to Resume Parser API.");
    }
} else {
    die("No file uploaded.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resume Insights</title>
    <link rel="stylesheet" href="css/parser_result.css"> <!-- Create this file for styling -->
</head>
<body>
    <div class="result-container">
        <h2>📄 Resume Analysis Results</h2>

        <div class="result-section">
            <h3>✅ Extracted Skills</h3>
            <ul>
                <?php foreach ($data['extracted_skills'] as $skill): ?>
                    <li><?php echo htmlspecialchars($skill); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="result-section">
            <h3>📌 Recommended Internships</h3>
            <ul>
                <?php foreach ($data['recommended_internships'] as $internship): ?>
                    <li><?php echo htmlspecialchars($internship); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="result-section">
            <h3>❌ Missing Skills (Improve Here)</h3>
            <ul>
                <?php foreach ($data['missing_skills'] as $gap): ?>
                    <li><?php echo htmlspecialchars($gap); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <a href="user_dashboard.php" class="btn">🔙 Back to Dashboard</a>
    </div>
</body>
</html>
