import sys
import json
import re
from PyPDF2 import PdfReader
import sys

if len(sys.argv) < 2:
    print("Usage: python resume_parser.py <file_path>")
    sys.exit(1)

file_path = sys.argv[1]
# Continue with parsing...


def extract_text_from_pdf(file_path):
    reader = PdfReader(file_path)
    text = ''
    for page in reader.pages:
        text += page.extract_text()
    return text.lower()

def extract_skills(text):
    skill_set = ['python', 'java', 'html', 'css', 'javascript', 'machine learning', 'sql']
    found = [skill for skill in skill_set if skill in text]
    return found

def recommend_internships(skills):
    internships = {
        "python": "Backend Development",
        "html": "Frontend Internship",
        "machine learning": "AI/ML Research",
    }
    return list(set([internships[skill] for skill in skills if skill in internships]))

if __name__ == "__main__":
    file_path = sys.argv[1]
    content = extract_text_from_pdf(file_path)
    skills = extract_skills(content)
    recommendations = recommend_internships(skills)

    print(json.dumps({
        "skills": skills,
        "recommendations": recommendations
    }))
