<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Internship | Internship Portal</title>
    <link rel="stylesheet" href="css/style.css">  <!-- General Styles -->
    <link rel="stylesheet" href="css/submit_internship.css">  <!-- Page-Specific Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
<body style="background: url('images/sub_int.jpg') no-repeat center center fixed; background-size: cover;"></body>ader>
<header class="transparent-header">
    <div class="logo">Internship Portal</div>
    <nav>
        <ul>
            <li><a href="employer_dashboard.php" class="nav-btn">Dashboard</a></li>
            <li><a href="manage_internships.php" class="nav-btn">Manage Internships</a></li>
            <li><a href="post_internship.php" class="nav-btn">Post Internship</a></li>
            <li><a href="employer_messages.php" class="nav-btn">Messages</a></li>
            <li><a href="employer_profile.php" class="nav-btn">Profile</a></li>
            <li><a href="logout.php" class="nav-btn logout-btn">Logout</a></li>
        </ul>
    </nav>
</header>

<!-- Page Background -->
<div class="submit-internship-background">
    <div class="submit-internship-container">
        <h1 class="submit-internship-title">Internship Submitted Successfully!</h1>
        <p class="submit-internship-desc">Your internship post has been successfully added to the portal.</p>

        <div class="submit-actions">
            <a href="manage_internships.php" class="action-btn"><i class="fas fa-briefcase"></i> Manage Internships</a>
            <a href="post_internship.php" class="action-btn"><i class="fas fa-plus"></i> Post Another Internship</a>
            <a href="employer_dashboard.php" class="action-btn"><i class="fas fa-home"></i> Back to Dashboard</a>
        </div>
    </div>
</div>

</body>
</html>
