<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $email = htmlspecialchars($_POST["email"]);
    $message = htmlspecialchars($_POST["message"]);

    // Email Configuration
    $to = "admin@example.com";  // Replace with your email
    $subject = "New Contact Form Submission";
    $headers = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    $emailBody = "
        <html>
        <head>
            <style>
                body { font-family: 'Poppins', sans-serif; background: #f4f4f4; margin: 0; padding: 20px; text-align: center; }
                .container { background: white; padding: 30px; border-radius: 10px; max-width: 600px; margin: 50px auto; box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.15); }
                h1 { color: #007bff; margin-bottom: 15px; }
                p { font-size: 1.2rem; color: #555; }
                .success { color: green; }
                .error { color: red; }
                a { text-decoration: none; color: white; background: #007bff; padding: 12px 25px; border-radius: 8px; font-size: 1.2rem; display: inline-block; margin-top: 15px; }
                a:hover { background: #0056b3; }
            </style>
        </head>
        <body>
            <div class='container'>
                <h1>Contact Form Submission</h1>
                <p><strong>Name:</strong> $name</p>
                <p><strong>Email:</strong> $email</p>
                <p><strong>Message:</strong></p>
                <p>$message</p>
            </div>
        </body>
        </html>
    ";

    // Send Email
    if (mail($to, $subject, $emailBody, $headers)) {
        echo "<div class='container'><h1 class='success'>Message Sent Successfully! ✅</h1>";
    } else {
        echo "<div class='container'><h1 class='error'>Error Sending Message ❌</h1>";
    }
    echo "<a href='contact.php'>Go Back</a></div>";
}
?>
