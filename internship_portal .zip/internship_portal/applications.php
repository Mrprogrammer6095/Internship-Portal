<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Applications | Internship Portal</title>
    <link rel="stylesheet" href="css/style.css">  <!-- General Styles -->
    <link rel="stylesheet" href="css/applications.css">  <!-- Page-Specific Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
<body style="background: url('images/applications.jpg') no-repeat center center fixed; background-size: cover;"></body>
<header>
    <div class="logo">Internship Portal</div>
    <nav>
        <ul>
            <li><a href="dashboard.php" class="nav-btn">Dashboard</a></li>
            <li><a href="internships.php" class="nav-btn">Internships</a></li>
            <li><a href="applications.php" class="nav-btn active">Applications</a></li>
            <li><a href="profile.php" class="nav-btn">Profile</a></li>
            <li><a href="logout.php" class="nav-btn">Logout</a></li>
        </ul>
    </nav>
</header>

<!-- Applications Table -->
<div class="applications-container">
    <h2>My Applications</h2>
    <table>
        <thead>
            <tr>
                <th>Company</th>
                <th>Position</th>
                <th>Status</th>
                <th>Applied On</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Google</td>
                <td>Software Engineer Intern</td>
                <td class="status-pending">Pending</td>
                <td>March 28, 2025</td>
                <td><button class="withdraw-btn">Withdraw</button></td>
            </tr>
            <tr>
                <td>Microsoft</td>
                <td>Cybersecurity Analyst Intern</td>
                <td class="status-accepted">Accepted</td>
                <td>March 15, 2025</td>
                <td><button class="view-btn">View</button></td>
            </tr>
            <tr>
                <td>Amazon</td>
                <td>Network Engineer Intern</td>
                <td class="status-rejected">Rejected</td>
                <td>March 10, 2025</td>
                <td><button class="disabled-btn" disabled>Closed</button></td>
            </tr>
        </tbody>
    </table>
</div>

</body>
</html>
