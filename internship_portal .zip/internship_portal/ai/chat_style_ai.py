def chat_response(message):
    # Basic bot logic
    message = message.lower()

    if "internship" in message:
        return "You can find internships under the 'Internships' section!"
    elif "skills" in message:
        return "Upload your resume to detect your skills and find what you're missing."
    elif "hello" in message or "hi" in message:
        return "Hello! How can I assist you with your internship or career today?"
    elif "thank you" in message:
        return "You're welcome! Feel free to ask more questions."
    else:
        return f"You said: {message}. I'm here to help with anything related to internships, skills, and careers!"
