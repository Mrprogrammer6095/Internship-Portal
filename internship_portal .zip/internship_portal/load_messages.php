<?php
include 'config.php';
session_start();

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM messages ORDER BY timestamp ASC";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()): ?>
    <div class="chat-message <?= ($row['user_id'] == $user_id) ? 'sent' : 'received' ?>">
        <span class="user"><?= ($row['user_id'] == $user_id) ? 'You' : 'User ' . $row['user_id'] ?>:</span>
        <p><?= htmlspecialchars($row['message']) ?></p>
        <span class="time"><?= date("h:i A", strtotime($row['timestamp'])) ?></span>
    </div>
<?php endwhile; ?>
