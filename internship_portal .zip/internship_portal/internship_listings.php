<?php
include 'config.php';
session_start();

// Fetch internships from the database
$sql = "SELECT * FROM internships";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Internship Listings</title>
    <link rel="stylesheet" href="css/styles.css"> <!-- Ensure styles.css is linked properly -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
        <h2 class="page-title">Available Internships</h2>
        <div class="internship-grid">
            <?php while ($row = $result->fetch_assoc()) { ?>
                <div class="internship-card">
                    <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                    <p><strong>Company:</strong> <?php echo htmlspecialchars($row['company']); ?></p>
                    <p><strong>Location:</strong> <?php echo htmlspecialchars($row['location']); ?></p>
                    <p><strong>Stipend:</strong> ₹<?php echo htmlspecialchars($row['salary']); ?></p>
                    <p class="description"><?php echo nl2br(htmlspecialchars($row['description'])); ?></p>
                    <a href="apply.php?id=<?php echo $row['id']; ?>" class="apply-btn">Apply Now</a>
                </div>
            <?php } ?>
        </div>
    </div>
</body>
</html>
