<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link rel="stylesheet" href="css/manage_users.css">
</head>
<body>
<body style="background: url('images/.jpg') no-repeat center center fixed; background-size: cover;"></body>
    <header>
        <h2>Manage Users</h2>
        <a href="admin_dashboard.php" class="back-btn">Back</a>
    </header>

    <div class="dashboard-container">
        <div class="card">
            <h3>View All Users</h3>
            <p>See registered users and their details.</p>
            <a href="view_users.php">View Users</a>
        </div>

        <div class="card">
            <h3>Delete User</h3>
            <p>Remove inactive or fake accounts.</p>
            <a href="delete_users.php">Delete User</a>
        </div>
    </div>

</body>
</html>
