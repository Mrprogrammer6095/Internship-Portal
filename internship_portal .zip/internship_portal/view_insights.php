<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

// Fetch data
$total_users = $conn->query("SELECT COUNT(*) AS total FROM users")->fetch_assoc()['total'];
$total_employers = $conn->query("SELECT COUNT(*) AS total FROM employers")->fetch_assoc()['total'];
$total_internships = $conn->query("SELECT COUNT(*) AS total FROM internships")->fetch_assoc()['total'];
$total_applications = $conn->query("SELECT COUNT(*) AS total FROM applications")->fetch_assoc()['total'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Insights</title>
    <link rel="stylesheet" href="css/view_insights.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="insight-container">
        <h2>Admin Analytics Dashboard</h2>
        <div class="stats-box">
            <div class="card">👥 Users: <span><?= $total_users ?></span></div>
            <div class="card">🏢 Employers: <span><?= $total_employers ?></span></div>
            <div class="card">📄 Internships: <span><?= $total_internships ?></span></div>
            <div class="card">📨 Applications: <span><?= $total_applications ?></span></div>
        </div>

        <canvas id="analyticsChart" width="600" height="300"></canvas>
    </div>

    <script>
        const ctx = document.getElementById('analyticsChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Users', 'Employers', 'Internships', 'Applications'],
                datasets: [{
                    label: 'Platform Stats',
                    data: [<?= $total_users ?>, <?= $total_employers ?>, <?= $total_internships ?>, <?= $total_applications ?>],
                    backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e'],
                    borderRadius: 5
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
