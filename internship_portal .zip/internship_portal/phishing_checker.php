<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Phishing URL Checker</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #eef2f3;
      padding: 20px;
    }
    .box {
      max-width: 600px;
      margin: auto;
      background: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    input[type="text"] {
      width: 80%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
    button {
      padding: 10px 15px;
      margin-left: 5px;
      background-color: #28a745;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    button:hover {
      background-color: #218838;
    }
    .result {
      margin-top: 20px;
      font-weight: bold;
      color: #333;
    }
  </style>
</head>
<body>
  <div class="box">
    <h2>Phishing URL Checker</h2>
    <input type="text" id="urlInput" placeholder="Enter URL to check..." onkeypress="handleKeyPress(event)" />
    <button onclick="checkURL()">Check</button>
    <div class="result" id="resultText"></div>
  </div>

  <script>
    async function checkURL() {
      const resultBox = document.getElementById('resultText');
      const url = document.getElementById('urlInput').value.trim();

      if (!url) {
        resultBox.innerText = "Please enter a URL.";
        return;
      }

      resultBox.innerText = "Checking...";
      try {
        const response = await fetch('http://localhost:5001/check-url', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ url })
        });

        const data = await response.json();
        if (data.result) {
          resultBox.innerText = `Result: ${data.result}`;
        } else if (data.error) {
          resultBox.innerText = `Error: ${data.error}`;
        } else {
          resultBox.innerText = `Unexpected response.`;
        }
      } catch (err) {
        resultBox.innerText = "Server error. Make sure Flask is running on port 5001.";
      }
    }

    function handleKeyPress(event) {
      if (event.key === 'Enter') {
        checkURL();
      }
    }
  </script>
</body>
</html>
