<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile | Internship Portal</title>
    <link rel="stylesheet" href="css/style.css">  <!-- General Styles -->
    <link rel="stylesheet" href="css/edit_profile.css">  <!-- Page-Specific Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
<body style="background: url('images/edit_profile.jpg') no-repeat center center fixed; background-size: cover;"></body>

<header>
    <div class="logo">Internship Portal</div>
    <nav>
        <ul>
            <li><a href="dashboard.php" class="nav-btn">Dashboard</a></li>
            <li><a href="internships.php" class="nav-btn">Internships</a></li>
            <li><a href="applications.php" class="nav-btn">Applications</a></li>
            <li><a href="profile.php" class="nav-btn active">Profile</a></li>
            <li><a href="logout.php" class="nav-btn">Logout</a></li>
        </ul>
    </nav>
</header>

<!-- Edit Profile Container -->
<div class="edit-profile-container">
    <h2>Edit Profile</h2>
    <form action="update_profile.php" method="POST">
        <label for="name"><i class="fa fa-user"></i> Full Name</label>
        <input type="text" id="name" name="name" placeholder="Enter your full name" required>

        <label for="email"><i class="fa fa-envelope"></i> Email</label>
        <input type="email" id="email" name="email" placeholder="Enter your email" required>

        <label for="contact"><i class="fa fa-phone"></i> Contact</label>
        <input type="tel" id="contact" name="contact" placeholder="Enter your contact number" required>

        <label for="location"><i class="fa fa-map-marker-alt"></i> Location</label>
        <input type="text" id="location" name="location" placeholder="Enter your location" required>

        <button type="submit" class="save-btn"><i class="fa fa-save"></i> Save Changes</button>
    </form>
</div>

</body>
</html>
