<?php
session_start();
include "db_connect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT id, email FROM employers WHERE email = ? AND password = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            $stmt->bind_result($employer_id, $employer_email);
            $stmt->fetch();

            // ✅ Save employer details in SESSION
            $_SESSION['employer_id'] = $employer_id;
            $_SESSION['email'] = $employer_email;

            header("Location: employer_dashboard.php");
            exit();
        } else {
            echo "❌ Invalid login credentials.";
        }
        $stmt->close();
    } else {
        echo "Database error: " . $conn->error;
    }
}
?>
