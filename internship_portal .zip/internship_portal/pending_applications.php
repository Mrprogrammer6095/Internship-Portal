<?php
include('db_connection.php');
$query = "SELECT * FROM applications WHERE status = 'pending'";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Applications</title>
    <link rel="stylesheet" href="css/pending_applications.css">
</head>
<body>
    <div class="container">
        <h1 class="page-title">Pending Applications</h1>
        <table class="applications-table">
            <thead>
                <tr>
                    <th>Application ID</th>
                    <th>Student Name</th>
                    <th>Position</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($app = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $app['id']; ?></td>
                        <td><?php echo $app['student_name']; ?></td>
                        <td><?php echo $app['position']; ?></td>
                        <td>
                            <button class="btn approve">Approve</button>
                            <button class="btn deny">Deny</button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
