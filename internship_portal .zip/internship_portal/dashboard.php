<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Internship Portal</title>
    <link rel="stylesheet" href="css/style.css">  <!-- General Styles -->
    <link rel="stylesheet" href="css/dashboard.css">  <!-- Dashboard-Specific Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>

<body style="background: url('images/dashboard.jpg') no-repeat center center fixed; background-size: cover;">

<!-- Dashboard Background -->
<div class="dashboard-background">

    <header>
        <div class="logo">Internship Portal</div>
        <nav>
            <ul>
                <li><a href="dashboard.php" class="nav-btn">Dashboard</a></li>
                <li><a href="internships.php" class="nav-btn">Internships</a></li>
                <li><a href="applications.php" class="nav-btn">Applications</a></li>
                <li><a href="profile.php" class="nav-btn">Profile</a></li>
                <li><a href="logout.php" class="nav-btn">Logout</a></li>
            </ul>
        </nav>
    </header>

    <div class="dashboard-container">

        <!-- Sidebar -->
        <div class="sidebar">
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="internships.php"><i class="fas fa-briefcase"></i> Internships</a></li>
                <li><a href="applications.php"><i class="fas fa-file-alt"></i> Applications</a></li>
                <li><a href="messages.php"><i class="fas fa-comments"></i> Messages</a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>

        <!-- Main Dashboard Content -->
        <div class="dashboard-main">
            
            <!-- Welcome Section -->
            <div class="welcome-section">
                <h1 class="welcome-text">Welcome, User!</h1>
                <p class="welcome-desc">Manage your internships, applications, and profile from here.</p>
            </div>

            <!-- Statistics Cards -->
            <div class="dashboard-stats">
                <div class="stat-card">
                    <i class="fas fa-briefcase"></i>
                    <h2>10</h2>
                    <p>Available Internships</p>
                </div>

                <div class="stat-card">
                    <i class="fas fa-file-alt"></i>
                    <h2>5</h2>
                    <p>Applications Submitted</p>
                </div>

                <div class="stat-card">
                    <i class="fas fa-comments"></i>
                    <h2>3</h2>
                    <p>New Messages</p>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="action-buttons">
                <a href="internships.php" class="action-btn"><i class="fas fa-search"></i> Browse Internships</a>
                <a href="applications.php" class="action-btn"><i class="fas fa-file-alt"></i> View Applications</a>
                <a href="profile.php" class="action-btn"><i class="fas fa-user"></i> Edit Profile</a>
            </div>
        </div>

    </div>
</div>

</body>
</html>
