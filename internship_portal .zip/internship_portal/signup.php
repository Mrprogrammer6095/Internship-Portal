<?php
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up | Internship Portal</title>
    <link rel="stylesheet" href="css/style.css">  <!-- General Styles -->
    <link rel="stylesheet" href="css/signup.css">  <!-- Signup Page Specific Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body style="background: url('images/signup.jpg') no-repeat center center fixed; background-size: cover;">
<!-- Signup Page Background -->

<div class="signup-container">
    <div class="signup-form">
        <h2>Create an Account</h2>
        <form action="register.php" method="POST">
            <!-- 🔐 Hidden CSRF token field -->
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">

            <div class="input-group">
                <label for="name"><i class="fas fa-user"></i> Full Name</label>
                <input type="text" id="name" name="name" placeholder="Enter your full name" required>
            </div>

            <div class="input-group">
                <label for="email"><i class="fas fa-envelope"></i> Email</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
            </div>

            <div class="input-group">
                <label for="password"><i class="fas fa-lock"></i> Password</label>
                <input type="password" id="password" name="password" placeholder="Create a password" required>
            </div>

            <div class="input-group">
                <label for="confirm-password"><i class="fas fa-lock"></i> Confirm Password</label>
                <input type="password" id="confirm-password" name="confirm_password" placeholder="Confirm your password" required>
            </div>

            <button type="submit" class="signup-btn">Sign Up</button>
        </form>
        
        <p class="login-link">Already have an account? <a href="login.php">Login here</a></p>
    </div>
</div>

</body>
</html>
