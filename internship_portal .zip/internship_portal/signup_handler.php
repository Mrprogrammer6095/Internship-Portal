<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash password

    // Insert into Database
    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $password);

    if ($stmt->execute()) {
        echo "<script>alert('Registration Successful! Please login.'); window.location.href='login.php';</script>";
    } else {
        echo "<script>alert('Error: Email already exists!'); window.location.href='signup.php';</script>";
    }
    $stmt->close();
}
?>
