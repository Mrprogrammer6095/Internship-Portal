function sendToAI() {
    const message = document.getElementById('chatInput').value;

    fetch('http://localhost:3000/chat-guidance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message })
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById('chatReply').innerText = data.reply;
    });
}

function checkPhishing() {
    const url = document.getElementById('urlInput').value;

    fetch('http://localhost:3000/phishing-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById('phishingResult').innerText = data.result;
    });
}
