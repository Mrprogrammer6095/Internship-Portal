document.getElementById('resumeForm').addEventListener('submit', async function (e) {
  e.preventDefault();

  const fileInput = document.getElementById('resumeInput');
  const file = fileInput.files[0];

  if (!file) {
    alert('Please select a resume file!');
    return;
  }

  const formData = new FormData();
  formData.append('resume', file);

  try {
    const res = await fetch('http://localhost:5000/upload', {
      method: 'POST',
      body: formData,
    });

    const data = await res.json();

    document.getElementById('summary').textContent = data.aiResult.summary;
    document.getElementById('skills').textContent = data.aiResult.skills.join(', ');
    document.getElementById('score').textContent = data.aiResult.score + '/100';
    document.getElementById('resultBox').style.display = 'block';
  } catch (err) {
    alert('Error uploading resume.');
    console.error(err);
  }
});
