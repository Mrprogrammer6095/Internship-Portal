<?php
$employer_id = 1; // Example employer ID
$sql = "SELECT * FROM reviews WHERE employer_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $employer_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    echo "<p>User " . $row['user_id'] . " rated " . $row['rating'] . " stars</p>";
    echo "<p>Review: " . $row['review'] . "</p>";
}
?>
