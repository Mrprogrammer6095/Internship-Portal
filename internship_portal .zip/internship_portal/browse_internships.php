<?php
include 'db.php';
$query = $conn->query("SELECT * FROM internships ORDER BY posted_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Browse Internships</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #7f00ff, #e100ff);
            color: #fff;
            padding: 40px 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 36px;
            color: #fff;
            letter-spacing: 1px;
        }

        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: auto;
        }

        .internship-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(8px);
            border-radius: 15px;
            padding: 20px;
            color: #fff;
            transition: all 0.3s ease-in-out;
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
        }

        .internship-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 40px rgba(0, 0, 0, 0.2);
        }

        .internship-card h3 {
            margin-top: 0;
            font-size: 22px;
            color: #ffffff;
        }

        .internship-card p {
            margin: 6px 0;
            color: #f0f0f0;
            font-size: 14px;
        }

        .btn {
            display: inline-block;
            padding: 8px 16px;
            background: #fff;
            color: #7f00ff;
            font-weight: bold;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 10px;
            transition: 0.3s;
        }

        .btn:hover {
            background: #e0e0e0;
            color: #4c00b0;
        }

        @media (max-width: 768px) {
            body {
                padding: 20px 10px;
            }
        }
    </style>
</head>
<body>
    <h2>Available Internships</h2>

    <div class="grid-container">
        <?php while ($row = $query->fetch_assoc()) : ?>
            <div class="internship-card">
                <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                <p><strong>Company:</strong> <?php echo htmlspecialchars($row['company_name']); ?></p>
                <p><strong>Location:</strong> <?php echo htmlspecialchars($row['location']); ?></p>
                <p><strong>Salary:</strong> ₹<?php echo htmlspecialchars($row['salary']); ?> / month</p>
                <p><strong>Description:</strong> <?php echo htmlspecialchars($row['description']); ?></p>
                <p><strong>Posted:</strong> <?php echo date('d M Y', strtotime($row['posted_at'])); ?></p>
                <a href="internship_details.php?id=<?php echo $row['id']; ?>" class="btn">View Details</a>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>
