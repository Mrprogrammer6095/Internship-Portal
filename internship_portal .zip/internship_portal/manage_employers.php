<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Employers</title>
    <link rel="stylesheet" href="css/manage_employers.css">
</head>
<body>

    <header>
        <h2>Manage Employers</h2>
        <a href="admin_dashboard.php" class="back-btn">Back</a>
    </header>

    <div class="dashboard-container">
        <div class="card">
            <h3>View Employers</h3>
            <p>Check employer details and verify authenticity.</p>
            <a href="view_employers.php">View Employers</a>
        </div>

        <div class="card">
            <h3>Approve/Reject</h3>
            <p>Approve or reject new employer applications.</p>
            <a href="approve_employers.php">Approve/Reject</a>
        </div>
    </div>

</body>
</html>
