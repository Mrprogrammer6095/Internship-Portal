<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $url = $_POST["url"];
    $cmd = escapeshellcmd("python recommend_api.py " . escapeshellarg($url));
    $output = shell_exec($cmd);
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Phishing URL Detector</title>
</head>
<body>
  <h2>Phishing URL Detection</h2>
  <form method="post">
    <input type="text" name="url" placeholder="Enter URL to check" required>
    <button type="submit">Check</button>
  </form>

  <?php if (!empty($output)) : ?>
    <h3>Result:</h3>
    <p><?php echo htmlspecialchars($output); ?></p>
  <?php endif; ?>
</body>
</html>
