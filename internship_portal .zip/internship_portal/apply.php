<?php
session_start();
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!isset($_SESSION['user_id'])) {
        die("❌ Unauthorized access. Please log in.");
    }

    $user_id = $_SESSION['user_id'];
    $internship_id = isset($_POST['internship_id']) ? intval($_POST['internship_id']) : 0;

    // Validate the internship ID
    if ($internship_id <= 0) {
        die("❌ Invalid internship selection.");
    }

    // Insert application into the database
    $stmt = $conn->prepare("INSERT INTO applications (user_id, internship_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $user_id, $internship_id);

    if ($stmt->execute()) {
        echo "✅ Application submitted successfully!";
    } else {
        echo "❌ Error submitting application: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
} else {
    die("❌ Invalid request method. Please submit the form properly.");
}
?>
