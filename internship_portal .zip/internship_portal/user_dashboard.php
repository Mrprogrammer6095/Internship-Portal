<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';
$user_id = $_SESSION['user_id'];
$query = $conn->prepare("SELECT full_name FROM users WHERE id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
$user = $result->fetch_assoc();
$query->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>User Dashboard | Internship Portal</title>
    <link rel="stylesheet" href="css/user_dashboard.css"/>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Navbar -->
        <nav class="navbar">
            <div class="navbar-left">
                <h2> Welcome, User...<?php echo htmlspecialchars($user['full_name']); ?></h2>
            </div>
            <div class="navbar-right">
                <a href="browse_internships.php">Browse</a>
                <a href="my_applications.php">Applications</a>
                <a href="saved_internships.php">Saved</a>
               
                <a href="settings.php">Settings</a>
                <a href="logout.php">Logout</a>
                <button id="dark-mode-toggle" title="Toggle Dark Mode">🌙</button>
            </div>
        </nav>

        <!-- Main Dashboard Content -->
        <main class="dashboard-content">
            <h3> User Dashboard</h3>
            <p>Manage internships, communicate with employers, and explore opportunities.</p>

            <!-- Dashboard Grid -->
            <div class="dashboard-grid">
                <a href="browse_internships.php" class="dashboard-card">
                    <i class="fas fa-search"></i>
                    <span>Browse Internships</span>
                </a>
                <a href="resume_analyzer.php" class="dashboard-card">
    <i class="fas fa-brain"></i>
    <span>AI-Resume Analyzer</span>
</a>

                <a href="my_applications.php" class="dashboard-card">
                    <i class="fas fa-folder-open"></i>
                    <span>My Applications</span>
                </a>
              
                
  
                <a href="settings.php" class="dashboard-card">
                    <i class="fas fa-cogs"></i>
                    <span>Settings</span>
                </a>
            </div>

            <div id="recommendations" class="recommendation-box">
    <h3>Recommended Internships</h3>
    <div id="recommendation-cards">
        <div class="recommendation-card">
            <h4>CNC Programming  Intern</h4>
            <p>Company: Toolcon Systems<br>Location: Pune<br>Duration: 6 months</p>
        </div>
        <div class="recommendation-card">
            <h4>Accounting Intern</h4>
            <p>Company: Jyoti Waghmode and Associates<br>Location: Pune<br>Duration: 6 months</p>
        </div>
        <div class="recommendation-card">
            <h4> CAD Design Intern</h4>
            <p>Company: Sanprotek Sanitary Process<br>Location: Pune<br>Duration: 6 months</p>
        </div>
    </div>
</div>


    <!-- Dark Mode Script -->
    <script>
        const toggleButton = document.getElementById('dark-mode-toggle');
        toggleButton.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            localStorage.setItem('darkMode', document.body.classList.contains('dark-mode'));
        });

        if (localStorage.getItem('darkMode') === 'true') {
            document.body.classList.add('dark-mode');
        }
    </script>
</body>
</html>
