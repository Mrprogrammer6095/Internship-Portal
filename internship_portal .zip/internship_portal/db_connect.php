<?php
$host = "localhost";
$user = "root";  // Change if using a different username
$password = "";  // Change if your database has a password
$dbname = "internship_portal";

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>
