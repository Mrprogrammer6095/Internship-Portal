<?php 
session_start(); 
if (isset($_GET['lang'])) {     
    $_SESSION['lang'] = $_GET['lang']; 
}  
if (!isset($_SESSION['lang'])) {     
    $_SESSION['lang'] = 'hi'; 
}  
switch ($_SESSION['lang']) {     
    case 'hi':         
        include('lang_hi.php');         
        break;     
    case 'mr': 
        // Add support for Marathi here if needed
        break; 
}  
?>  

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Internship Portal</title>
    <link rel="stylesheet" href="css/login.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: url('images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
        }

        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .login-form {
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(15px);
            box-shadow: 0 8px 32px rgba(0,0,0,0.2);
            padding: 40px 30px;
            border-radius: 16px;
            text-align: center;
            width: 100%;
            max-width: 400px;
            color: #fff;
        }

        .login-form h2 {
            margin-bottom: 25px;
            font-size: 28px;
            color: #ffffff;
        }

        .login-form input, .login-form select {
            width: 100%;
            padding: 12px 15px;
            margin: 10px 0;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            outline: none;
        }

        .login-form button {
            width: 100%;
            padding: 12px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .login-form button:hover {
            background: #388e3c;
        }

        .login-form p {
            margin-top: 15px;
            font-size: 14px;
            color: #f0f0f0;
        }

        .login-form a {
            color: #90caf9;
            text-decoration: none;
        }

        .login-form a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-form">
            <h2>Login</h2>
            <form action="process_login.php" method="POST">
                <input type="email" name="email" placeholder="Enter Email" required>
                <input type="password" name="password" placeholder="Enter Password" required>
                <select name="role" required>
                    <option value="user">User</option>
                    <option value="employer">Employer</option>
                    <option value="admin">Admin</option>
                </select>
                <button type="submit">Login</button>
            </form>
            <p>Don't have an account? <a href="signup.php">Sign up here</a></p>
        </div>
    </div>
</body>
</html>
