<?php
include 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    die("❌ Error: You must be logged in to upload a resume.");
}

$user_id = $_SESSION['user_id'];
$msg = "";

// Handle file upload
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["resume"])) {
    $target_dir = "uploads/resumes/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $file_name = basename($_FILES["resume"]["name"]);
    $target_file = $target_dir . $user_id . "_" . $file_name;
    $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Validate file type (Only PDF or DOCX)
    $allowed_types = ["pdf", "docx"];
    if (!in_array($file_type, $allowed_types)) {
        $msg = "❌ Invalid file format. Only PDF and DOCX allowed.";
    } elseif ($_FILES["resume"]["size"] > 5000000) {
        $msg = "❌ File size too large. Maximum 5MB allowed.";
    } elseif (move_uploaded_file($_FILES["resume"]["tmp_name"], $target_file)) {
        // Save resume path in database
        $sql = "UPDATE users SET resume = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $target_file, $user_id);

        if ($stmt->execute()) {
            $msg = "✅ Resume uploaded successfully!";
        } else {
            $msg = "❌ Database update failed: " . $conn->error;
        }
    } else {
        $msg = "❌ Error uploading file.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Upload Resume</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body class="resume-body">
    <div class="resume-container">
        <h2>Upload Your Resume</h2>
        <?php if ($msg) echo "<p class='message'>$msg</p>"; ?>
        <form action="" method="POST" enctype="multipart/form-data">
            <input type="file" name="resume" required>
            <button type="submit">Upload Resume</button>
        </form>
        <a href="dashboard.php" class="btn-back">Back to Dashboard</a>
    </div>
</body>
</html>
