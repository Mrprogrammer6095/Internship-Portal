<?php
include 'db_connection.php'; // Make sure to connect to your database

// Add a review and rating
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['review']) && isset($_POST['rating'])) {
    $employer_id = $_POST['employer_id'];  // Employer ID from which review is being posted
    $user_id = $_SESSION['user_id'];  // Get logged-in user ID from session
    $review = $_POST['review'];
    $rating = $_POST['rating'];

    $sql = "INSERT INTO reviews (employer_id, user_id, review, rating) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iisi", $employer_id, $user_id, $review, $rating);
    $stmt->execute();
    echo "Review submitted successfully!";
}
?>

<form action="reviews.php" method="POST">
    <input type="hidden" name="employer_id" value="1"> <!-- Example employer ID -->
    <textarea name="review" placeholder="Write your review" required></textarea>
    <select name="rating" required>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
    </select>
    <button type="submit">Submit Review</button>
</form>
