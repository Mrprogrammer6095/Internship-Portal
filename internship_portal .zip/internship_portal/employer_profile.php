<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employer Profile | Internship Portal</title>
    <link rel="stylesheet" href="css/employer_profile.css">  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
<body style="background: url('images/emp_profile.jpg') no-repeat center center fixed; background-size: cover;"></body>ader>
<header class="transparent-header">
    <div class="logo">Internship Portal</div>
    <nav>
        <ul>
            <li><a href="employer_dashboard.php" class="nav-btn">Dashboard</a></li>
            <li><a href="manage_internships.php" class="nav-btn">Manage Internships</a></li>
            <li><a href="post_internship.php" class="nav-btn">Post Internship</a></li>
            <li><a href="employer_messages.php" class="nav-btn">Messages</a></li>
            <li><a href="logout.php" class="nav-btn logout-btn">Logout</a></li>
        </ul>
    </nav>
</header>

<!-- Profile Background -->
<div class="profile-background">
    <div class="profile-container">
        <h1 class="profile-title">  Employer Profile</h1>

        <div class="profile-card">
            <img src="images/profile_pic.png" alt="Profile Picture" class="profile-image">
            <h2 class="profile-name">John Doe</h2>
            <p class="profile-company"><i class="fas fa-building"></i> ABC Tech Solutions</p>
            <p class="profile-email"><i class="fas fa-envelope"></i> johndoe@example.com</p>
            <p class="profile-phone"><i class="fas fa-phone"></i> +123 456 7890</p>

            <div class="profile-actions">
                <a href="edit_employer_profile.php" class="action-btn"><i class="fas fa-edit"></i> Edit Profile</a>
                <a href="change_password.php" class="action-btn"><i class="fas fa-key"></i> Change Password</a>
            </div>
        </div>
    </div>
</div>

</body>
</html>
