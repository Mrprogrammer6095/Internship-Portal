<?php
session_start();
include 'db.php';

if (!isset($_SESSION['employer_id'])) {
    die("Unauthorized access");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $employer_id = $_SESSION['employer_id'];
    $feedback = $_POST['feedback'];

    $stmt = $conn->prepare("INSERT INTO resume_feedback (user_id, employer_id, feedback) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $user_id, $employer_id, $feedback);

    if ($stmt->execute()) {
        echo "<script>alert('Feedback submitted successfully!'); window.location.href='employer_dashboard.php';</script>";
    } else {
        echo "<script>alert('Error submitting feedback.'); window.location.href='employer_dashboard.php';</script>";
    }

    $stmt->close();
}
?>
