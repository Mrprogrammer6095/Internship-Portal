<?php
session_start();
require_once "db_connection.php";

if (!isset($_SESSION['user_id'])) {
    die("❌ You must be logged in to view messages.");
}

$user_id = $_SESSION['user_id'];

// Get messages for this user
$sql = "SELECT messages.id, messages.sender_id, messages.receiver_id, messages.message, messages.timestamp, 
               users.full_name AS sender_name 
        FROM messages
        JOIN users ON messages.sender_id = users.id
        WHERE messages.sender_id = ? OR messages.receiver_id = ?
        ORDER BY messages.timestamp ASC";  // Ensure correct column

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
    <link rel="stylesheet" href="css/chat.css">
</head>
<body>
    <div class="chat-container">
        <h2>Messages</h2>
        <div class="chat-box">
            <?php while ($row = $result->fetch_assoc()) { ?>
                <div class="message <?= $row['sender_id'] == $user_id ? 'sent' : 'received'; ?>">
                    <strong><?= htmlspecialchars($row['sender_name']); ?>:</strong>
                    <p><?= htmlspecialchars($row['message']); ?></p>
                    <span class="timestamp"><?= $row['timestamp']; ?></span>
                </div>
            <?php } ?>
        </div>
        
        <form action="send_message.php" method="POST">
            <input type="hidden" name="sender_id" value="<?= $user_id; ?>">
            <input type="hidden" name="receiver_id" value="2">  <!-- Change dynamically -->
            <textarea name="message" placeholder="Type a message..." required></textarea>
            <button type="submit">Send</button>
        </form>
    </div>
</body>
</html>
