<?php
session_start();
if (!isset($_SESSION['employer_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_connect.php'; // Ensure your database connection file is included

$employer_id = $_SESSION['employer_id'];

// Fetch employer details
$query = "SELECT * FROM employers WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $employer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    die("Error: Employer not found.");
}

// Handle Profile Update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);

    if (!empty($name) && !empty($email)) {
        $updateQuery = "UPDATE employers SET name=?, email=? WHERE id=?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("ssi", $name, $email, $employer_id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            $success_msg = "Profile updated successfully!";
        } else {
            $error_msg = "No changes made.";
        }
    } else {
        $error_msg = "All fields are required!";
    }
}

// Handle Password Change
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_password'])) {
    $old_pass = md5($_POST['old_password']);
    $new_pass = md5($_POST['new_password']);

    if ($user['password'] == $old_pass) {
        $updatePassword = "UPDATE employers SET password=? WHERE id=?";
        $stmt = $conn->prepare($updatePassword);
        $stmt->bind_param("si", $new_pass, $employer_id);
        $stmt->execute();
        $success_msg = "Password changed successfully!";
    } else {
        $error_msg = "Old password is incorrect!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Employer Dashboard</title>
    <link rel="stylesheet" href="css/settings.css"> <!-- Make sure style.css is linked -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #121212;
            color: #fff;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 400px;
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
            backdrop-filter: blur(10px);
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.2);
        }

        h2 {
            text-align: center;
        }

        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: none;
            border-radius: 5px;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
            outline: none;
        }

        button {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border: none;
            border-radius: 5px;
            background: #1db954;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #1ed760;
        }

        .success {
            color: #1db954;
            text-align: center;
            margin-top: 10px;
        }

        .error {
            color: #ff4d4d;
            text-align: center;
            margin-top: 10px;
        }

        .dark-mode {
            background-color: #000;
            color: #fff;
        }

        #darkModeToggle {
            background: #ffbb33;
            margin-top: 10px;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #1db954;
            text-decoration: none;
            font-weight: bold;
        }

        .back-link:hover {
            color: #1ed760;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Settings</h2>

    <?php if (isset($success_msg)) echo "<p class='success'>$success_msg</p>"; ?>
    <?php if (isset($error_msg)) echo "<p class='error'>$error_msg</p>"; ?>

    <form method="POST">
        <label>Name:</label>
        <input type="text" name="name" value="<?php echo isset($user['name']) ? htmlspecialchars($user['name']) : ''; ?>" required>


        <label>Email:</label>
        <input type="email" name="email" value="<?php echo isset($user['email']) ? htmlspecialchars($user['email']) : ''; ?>" required>


        <button type="submit" name="update_profile">Update Profile</button>
    </form>

    <h3>Change Password</h3>
    <form method="POST">
        <label>Old Password:</label>
        <input type="password" name="old_password" required>

        <label>New Password:</label>
        <input type="password" name="new_password" required>

        <button type="submit" name="change_password">Change Password</button>
    </form>

    <button id="darkModeToggle">Toggle Dark Mode</button>

    <a href="employer_dashboard.php" class="back-link">Back to Dashboard</a>
</div>

<script>
    // Dark Mode Toggle
    const toggleButton = document.getElementById("darkModeToggle");
    const body = document.body;

    // Check local storage for dark mode preference
    if (localStorage.getItem("darkMode") === "enabled") {
        body.classList.add("dark-mode");
    }

    toggleButton.addEventListener("click", () => {
        if (body.classList.contains("dark-mode")) {
            body.classList.remove("dark-mode");
            localStorage.setItem("darkMode", "disabled");
        } else {
            body.classList.add("dark-mode");
            localStorage.setItem("darkMode", "enabled");
        }
    });
</script>

</body>
</html>
