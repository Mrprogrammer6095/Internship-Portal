<nav class = "navbar navbar-default navbar-fixed-top">
	<div class = "container-fluid">
		<a class="navbar-brand" href="#">
			<img src="../images/logo1.png" width="30" height="30" alt="">
		</a>
		<a class = "navbar-brand">INTERNSHIP PORTAL MANAGEMENT SYSTEM </a>
	<div>
</nav>