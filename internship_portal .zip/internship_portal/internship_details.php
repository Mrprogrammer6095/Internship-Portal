<?php
include 'db.php';

if (!isset($_GET['id'])) {
    echo "Invalid Request";
    exit();
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM internships WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$internship = $result->fetch_assoc();
$stmt->close();

if (!$internship) {
    echo "Internship not found!";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Internship Details</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #7f00ff, #e100ff);
            color: #fff;
            padding: 40px 20px;
        }

        .details-container {
            max-width: 800px;
            margin: auto;
            background: rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 15px;
            backdrop-filter: blur(8px);
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
        }

        h2 {
            margin-top: 0;
            font-size: 32px;
            color: #fff;
        }

        .info {
            margin-top: 20px;
        }

        .info p {
            font-size: 16px;
            margin: 10px 0;
            color: #eaeaea;
        }

        .label {
            font-weight: bold;
            color: #fff;
        }

        .btn-back {
            margin-top: 20px;
            display: inline-block;
            padding: 10px 16px;
            background: #fff;
            color: #7f00ff;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s ease;
        }

        .btn-back:hover {
            background: #e0e0e0;
            color: #4c00b0;
        }

        @media (max-width: 768px) {
            .details-container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<div class="details-container">
    <h2><?php echo htmlspecialchars($internship['title']); ?></h2>

    <div class="info">
        <p><span class="label">Company:</span> <?php echo htmlspecialchars($internship['company_name']); ?></p>
        <p><span class="label">Location:</span> <?php echo htmlspecialchars($internship['location']); ?></p>
        <p><span class="label">Salary:</span> ₹<?php echo htmlspecialchars($internship['salary']); ?> / month</p>
        <p><span class="label">Description:</span> <?php echo htmlspecialchars($internship['description']); ?></p>
        <p><span class="label">Posted on:</span> <?php echo date('d M Y', strtotime($internship['posted_at'])); ?></p>
    </div>

    <a href="browse_internships.php" class="btn-back">← Back to Browse</a>
</div>

</body>
</html>
