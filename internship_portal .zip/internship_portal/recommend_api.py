from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)
CORS(app)

# Sample internship dataset (replace with DB fetch if needed)
internships = pd.DataFrame([
    {"id": 1, "title": "Frontend Developer", "tags": "html css javascript react"},
    {"id": 2, "title": "Backend Developer", "tags": "php mysql laravel"},
    {"id": 3, "title": "AI Intern", "tags": "machine learning python nlp"},
    {"id": 4, "title": "Cybersecurity Analyst", "tags": "network security pentesting nmap"},
    {"id": 5, "title": "Data Analyst", "tags": "data python excel visualization"}
])

@app.route('/recommend', methods=['POST'])
def recommend():
    data = request.get_json()
    user_skills = data['skills']

    # Combine user skills with internship tags
    corpus = [user_skills] + internships['tags'].tolist()
    
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(corpus)
    cosine_sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:]).flatten()

    internships['score'] = cosine_sim
    top_recommendations = internships.sort_values(by='score', ascending=False).head(5)
    return jsonify(top_recommendations.to_dict(orient='records'))

if __name__ == '__main__':
    app.run(debug=True)
