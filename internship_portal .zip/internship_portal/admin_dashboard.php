<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
include 'db.php';

$admin_id = $_SESSION['admin_id'];
$query = $conn->prepare("SELECT email FROM admin WHERE id = ?");
$query->bind_param("i", $admin_id);
$query->execute();
$result = $query->get_result();
$admin = $result->fetch_assoc();
$query->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="css/admin_dashboard.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
  <div class="dashboard-container">
    <!-- Navbar -->
    <nav class="navbar">
      <div class="navbar-left">
        <h2>Welcome, Admin</h2>
      </div>
      <div class="navbar-right">
        <a href="manage_users.php">Users</a>
        <a href="manage_employers.php">Employers</a>
        <a href="view_insights.php">Insights</a>
        <a href="view_applications.php">Applications</a>
        <a href="admin_resume_insights.php">Resume Insights</a>
        <a href="logout.php">Logout</a>
        <button id="dark-mode-toggle" title="Toggle Dark Mode">🌙</button>
      </div>
    </nav>

    <!-- Dashboard Content -->
    <main class="dashboard-content">
      <h3>Admin Dashboard</h3>
      <p>Control and manage all aspects of the Internship Portal.</p>

      <div class="dashboard-grid">
        <a href="manage_users.php" class="dashboard-card">
          <i class="fas fa-users"></i>
          <span>Manage Users</span>
        </a>
        <a href="manage_employers.php" class="dashboard-card">
          <i class="fas fa-building"></i>
          <span>Manage Employers</span>
        </a>
        <a href="view_insights.php" class="dashboard-card">
          <i class="fas fa-chart-line"></i>
          <span>Platform Insights</span>
        </a>
        <a href="view_applications.php" class="dashboard-card">
          <i class="fas fa-clipboard-list"></i>
          <span>View Applications</span>
        </a>
        <a href="admin_resume_insights.php" class="dashboard-card">
          <i class="fas fa-file-alt"></i>
          <span>Resume Insights</span>
        </a>
        <a href="logout.php" class="dashboard-card">
          <i class="fas fa-sign-out-alt"></i>
          <span>Logout</span>
        </a>
      </div>
    </main>
  </div>

  <script>
    const toggleButton = document.getElementById('dark-mode-toggle');
    toggleButton.addEventListener('click', () => {
      document.body.classList.toggle('dark-mode');
      localStorage.setItem('adminDarkMode', document.body.classList.contains('dark-mode'));
    });

    if (localStorage.getItem('adminDarkMode') === 'true') {
      document.body.classList.add('dark-mode');
    }
  </script>
</body>
</html>
