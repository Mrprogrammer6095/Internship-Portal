<?php
include('db_connection.php');
if (isset($_GET['id'])) {
    $employer_id = $_GET['id'];
    $query = "UPDATE employers SET status = 'approved' WHERE id = '$employer_id'";
    if (mysqli_query($conn, $query)) {
        echo "Employer approved successfully!";
    } else {
        echo "Error approving employer: " . mysqli_error($conn);
    }
}
?>
