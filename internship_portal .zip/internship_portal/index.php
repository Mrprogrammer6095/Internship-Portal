<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome | Internship Portal</title>
    <link rel="stylesheet" href="css/style.css"> <!-- General Styles -->
    <link rel="stylesheet" href="css/index.css"> <!-- Index Page Specific Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background: url('images/index.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
        }
    </style>
</head>
<body>

<header>
    <div class="logo">Internship Portal</div>
    <nav>
        <ul>
            <li><a href="index.php" class="nav-btn">Home</a></li>
            <li><a href="internships.php" class="nav-btn">Internships</a></li>
            <li><a href="login.php" class="nav-btn">Login</a></li>
            <li><a href="ai_assist.php">AI Chat</a></li>
            <li><a href="phishing_checker.php">Phishing Check</a></li>
            <li><a href="signup.php" class="nav-btn">Sign Up</a></li>
            <li><a href="contact.php" class="nav-btn">Contact</a></li>
        </ul>
    </nav>
</header>

<!-- Hero Section -->
<div class="hero-section">
    <div class="hero-text">
        <h1>Find Your Dream Internship</h1>
        <p>Connect with top companies and grow your career.</p>
        <a href="signup.php" class="cta-btn">Get Started</a>
    </div>
</div>

</body>
</html>
