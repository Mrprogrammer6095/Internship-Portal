<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile | Internship Portal</title>
    <link rel="stylesheet" href="css/style.css">  <!-- General Styles -->
    <link rel="stylesheet" href="css/profile.css">  <!-- Profile-Specific Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>

<body style="background: url('images/profile.jpg') no-repeat center center fixed; background-size: cover;"></body>
<header>
    <div class="logo">Internship Portal</div>
    <nav>
        <ul>
            <li><a href="dashboard.php" class="nav-btn">Dashboard</a></li>
            <li><a href="internships.php" class="nav-btn">Internships</a></li>
            <li><a href="applications.php" class="nav-btn">Applications</a></li>
            <li><a href="profile.php" class="nav-btn active">Profile</a></li>
            <li><a href="logout.php" class="nav-btn">Logout</a></li>
        </ul>
    </nav>
</header>

<!-- Profile Section -->
<div class="profile-container">
    <div class="profile-card">
        <div class="profile-header">
            <img src="images/user.png" alt="Profile Picture" class="profile-pic">
            <h2>John Doe</h2>
            <p class="profile-email">johndoe@example.com</p>
        </div>
        <div class="profile-details">
            <h3>Personal Information</h3>
            <p><i class="fas fa-user"></i> Full Name: <b>John Doe</b></p>
            <p><i class="fas fa-envelope"></i> Email: <b>johndoe@example.com</b></p>
            <p><i class="fas fa-phone"></i> Contact: <b>+123 456 7890</b></p>
            <p><i class="fas fa-map-marker-alt"></i> Location: <b>New York, USA</b></p>
        </div>
        <div class="profile-actions">
            <a href="edit_profile.php" class="edit-btn"><i class="fas fa-edit"></i> Edit Profile</a>
            <a href="change_password.php" class="change-pass-btn"><i class="fas fa-lock"></i> Change Password</a>
        </div>
    </div>
</div>

</body>
</html>
