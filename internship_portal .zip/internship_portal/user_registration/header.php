<html>
<head> 
    <link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/style.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/jquery-ui.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/jquery.dataTables.css" />
    </head>
    <nav class = "navbar navbar-default navbar-fixed-top">
	<div class = "container-fluid">
			<img class = "pull-left" src="../images/logo1.png" width="50" height="50" alt="logo">
		<a href="../index.php" class = "navbar-brand">InternMSU</a>
	<div>
</nav>
</html>
