<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Resume Parser | Internship Portal</title>
    <link rel="stylesheet" href="css/resume_parser.css">
</head>
<body>
    <div class="container">
        <h2>Resume Analyzer</h2>
        <p>Upload your resume (PDF only) to extract skills and match internships.</p>

        <form action="process_resume_pdf.php" method="POST" enctype="multipart/form-data">
            <input type="file" name="resume" accept="application/pdf" required>
            <button type="submit">Analyze Resume</button>
        </form>

        <?php if (isset($_GET['error'])): ?>
            <p class="error"><?= htmlspecialchars($_GET['error']) ?></p>
        <?php endif; ?>
        <?php if (isset($_GET['success'])): ?>
            <p class="success"><?= htmlspecialchars($_GET['success']) ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
