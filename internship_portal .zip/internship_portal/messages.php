<?php
session_start();
include 'db_connection.php';

// Check login
if (!isset($_SESSION['user_id'])) {
    echo "You must be logged in to view messages.";
    exit;
}

$user_id = $_SESSION['user_id'];
$receiver_id = isset($_POST['receiver_id']) ? intval($_POST['receiver_id']) : 2;

// Assuming user is logged in
$user_id = $_SESSION['user_id'];
$receiver_id = isset($_POST['receiver_id']) ? intval($_POST['receiver_id']) : 2; // Default receiver

// Send message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $message = trim($_POST['message']);

    if (!empty($message)) {
        $sql = "INSERT INTO messages (sender_id, receiver_id, message, sent_at) VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iis", $user_id, $receiver_id, $message);
        $stmt->execute();
    }
}

// Retrieve messages between logged-in user and receiver
$sql = "SELECT * FROM messages 
        WHERE (sender_id = ? AND receiver_id = ?) 
           OR (sender_id = ? AND receiver_id = ?) 
        ORDER BY sent_at ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iiii", $user_id, $receiver_id, $receiver_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Messages</title>
    <link rel="stylesheet" href="css/messages.css">
    <style>
        .chat-box { max-width: 500px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; }
        .messages { max-height: 300px; overflow-y: auto; margin-bottom: 15px; }
        .sent { text-align: right; color: green; }
        .received { text-align: left; color: blue; }
        textarea { width: 100%; height: 60px; }
    </style>
</head>
<body>
    <div class="chat-box">
        <h2>Chat with User #<?= htmlspecialchars($receiver_id) ?></h2>
        <div class="messages">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="<?= $row['sender_id'] == $user_id ? 'sent' : 'received' ?>">
                    <p><?= htmlspecialchars($row['message']) ?></p>
                    <small><?= $row['sent_at'] ?></small>
                </div>
            <?php endwhile; ?>
        </div>

        <form action="messages.php" method="POST" class="message-form">
            <input type="hidden" name="receiver_id" value="<?= htmlspecialchars($receiver_id) ?>">
            <textarea name="message" placeholder="Type your message..." required></textarea>
            <button type="submit">Send</button>
        </form>
    </div>
</body>
</html>
