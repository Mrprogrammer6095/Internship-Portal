<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['employer_id'])) {
    header("Location: login.php");
    exit();
}

$employer_id = $_SESSION['employer_id'];

$sql = "SELECT users.id, users.full_name, users.email FROM users 
        INNER JOIN applications ON users.id = applications.user_id 
        INNER JOIN internships ON applications.internship_id = internships.id
        WHERE internships.employer_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $employer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['send_message'])) {
    $user_id = $_POST['user_id'];
    $message = $_POST['message'];

    if (!empty($message)) {
        $insert_sql = "INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)";
        $stmt_insert = $conn->prepare($insert_sql);
        $stmt_insert->bind_param("iis", $employer_id, $user_id, $message);
        $stmt_insert->execute();
        $success_message = "Message sent successfully!";
    } else {
        $error_message = "Message cannot be empty.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message Applicants</title>
    <link rel="stylesheet" href="css/theme.css">
</head>
<body>

    <div class="theme-toggle">
        <span>🌞</span>
        <input type="checkbox" id="theme-switch">
        <span>🌙</span>
    </div>

    <div class="dashboard-container">
        <h2>Message Applicants</h2>

        <?php if (isset($success_message)) { ?>
            <p class="success"><?php echo $success_message; ?></p>
        <?php } ?>
        <?php if (isset($error_message)) { ?>
            <p class="error"><?php echo $error_message; ?></p>
        <?php } ?>

        <form method="POST">
            <label for="user_id">Select Applicant:</label>
            <select name="user_id" required>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <option value="<?php echo $row['id']; ?>">
                        <?php echo htmlspecialchars($row['full_name'] . " (" . $row['email'] . ")"); ?>
                    </option>
                <?php } ?>
            </select>

            <label for="message">Message:</label>
            <textarea name="message" required></textarea>

            <button type="submit" name="send_message">Send Message</button>
        </form>
    </div>

    <script>
        // Theme Toggle Script
        const themeSwitch = document.getElementById("theme-switch");

        if (localStorage.getItem("theme") === "dark") {
            document.body.classList.add("dark-mode");
            themeSwitch.checked = true;
        }

        themeSwitch.addEventListener("change", () => {
            document.body.classList.toggle("dark-mode");
            localStorage.setItem("theme", document.body.classList.contains("dark-mode") ? "dark" : "light");
        });
    </script>

</body>
</html>
