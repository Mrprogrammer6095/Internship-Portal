<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $target_dir = "resumes/";
    $target_file = $target_dir . basename($_FILES["resume"]["name"]);

    if (move_uploaded_file($_FILES["resume"]["tmp_name"], $target_file)) {
        $command = escapeshellcmd("python extract_resume_skills.py " . escapeshellarg($target_file));
        $output = shell_exec($command);
        $skills = json_decode($output, true);

        echo "<h3>Extracted Skills:</h3><ul>";
        foreach ($skills['skills'] as $skill) {
            echo "<li>" . htmlspecialchars($skill) . "</li>";
        }
        echo "</ul>";

        // Save to session or DB for internship matching
        $_SESSION['extracted_skills'] = $skills['skills'];
    } else {
        echo "Error uploading resume.";
    }
}
?>

<form method="POST" enctype="multipart/form-data">
    <label>Upload Resume (PDF only):</label>
    <input type="file" name="resume" accept=".pdf" required>
    <button type="submit">Extract Skills</button>
</form>
