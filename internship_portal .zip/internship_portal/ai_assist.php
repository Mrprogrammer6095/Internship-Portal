<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>AI Assistant</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f1f1f1;
      padding: 20px;
    }
    .chat-box {
      max-width: 600px;
      margin: auto;
      background: #fff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .message {
      margin: 10px 0;
    }
    .user {
      font-weight: bold;
      color: #007bff;
    }
    .ai {
      color: #28a745;
    }
    input[type="text"] {
      width: 80%;
      padding: 10px;
      margin-top: 10px;
    }
    button {
      padding: 10px;
      margin-left: 5px;
    }
    #chatLog {
      max-height: 400px;
      overflow-y: auto;
      border: 1px solid #ccc;
      padding: 10px;
      margin-bottom: 10px;
      border-radius: 5px;
      background: #fafafa;
    }
  </style>
</head>
<body>
  <div class="chat-box">
    <h2>AI Assistant</h2>
    <div id="chatLog"></div>
    <input type="text" id="userInput" placeholder="Ask something..." />
    <button onclick="sendMessage()">Send</button>
  </div>

  <script>
async function sendMessage() {
  const userInput = document.getElementById('userInput').value;
  if (!userInput) return;

  document.getElementById('chatLog').innerHTML += `<div class="message user">You: ${userInput}</div>`;
  document.getElementById('userInput').value = '';

  try {
    const response = await fetch('http://localhost:5001/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_input: userInput })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();

    if (data.response) {
      document.getElementById('chatLog').innerHTML += `<div class="message ai">AI: ${data.response}</div>`;
    } else {
      document.getElementById('chatLog').innerHTML += `<div class="message ai">AI: Error getting response</div>`;
    }
  } catch (error) {
    console.error('Fetch error:', error);
    document.getElementById('chatLog').innerHTML += `<div class="message ai">AI: Failed to contact server</div>`;
  }
}

  </script>
</body>
</html>
